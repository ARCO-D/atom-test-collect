export PATH=$PATH:/home/arco/x-tools/gcc-linaro-11.3.1-2022.06-x86_64_arm-linux-gnueabihf/bin/
export ARCH=arm
export CROSS_COMPILE="arm-linux-gnueabihf-"

